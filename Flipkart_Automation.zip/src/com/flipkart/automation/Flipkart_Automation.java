package com.flipkart.automation;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;
import org.openqa.selenium.JavascriptExecutor;

public class Flipkart_Automation {
	
	@Test
	public void test() throws InterruptedException {
	
	System.setProperty("webdriver.grecko.driver","C:\\Users\\Ravi\\eclipse-workspace\\Flipkart_Automation\\geckodriver.exe");
	WebDriver driver=new FirefoxDriver();
	driver.manage().window().maximize();
	//driver.manage().Timeout(60,TimeUnit.SECONDS);
	driver.manage().timeouts().pageLoadTimeout(60,TimeUnit.SECONDS);
	//driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);
	//Thread.sleep(100);
    driver.get("https://www.flipkart.com/");
	Thread.sleep(100);
	driver.findElement(By.xpath("/html/body/div[2]/div/div/button")).click();
	driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div[1]/div[2]/div[2]/form/div/div/input")).sendKeys("Samsung Phones");
	driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div[1]/div[2]/div[2]/form/div/button")).click();
	Thread.sleep(200);
	JavascriptExecutor jse= (JavascriptExecutor) driver;
	jse.executeScript("scroll(0,300);");
	Thread.sleep(3000);
	
	
	jse.executeScript("scroll(300,600);");
	Thread.sleep(3000);
	
	System.out.println("Selecting the phones");
	System.out.println("Phone-1");
	System.out.println(driver.findElement(By.xpath("/html/body/div[1]/div/div[3]/div[2]/div[1]/div[2]/div[2]/div/div/div/a/div[2]/div[1]/div[1]")).getText());
	System.out.println(driver.findElement(By.xpath("/html/body/div[1]/div/div[3]/div[2]/div[1]/div[2]/div[2]/div/div/div/a/div[2]/div[2]/div[1]/div/div[1]")).getText());
	
	jse.executeScript("scroll(600,900);");
	Thread.sleep(3000);
	Thread.sleep(1000);
	System.out.print("Phone-2");
	System.out.println(driver.findElement(By.xpath("/html/body/div[1]/div/div[3]/div[2]/div[1]/div[2]/div[3]/div/div/div/a/div[2]/div[1]/div[1]")).getText());
	System.out.println(driver.findElement(By.xpath("/html/body/div[1]/div/div[3]/div[2]/div[1]/div[2]/div[3]/div/div/div/a/div[2]/div[2]/div[1]/div/div[1]")).getText());
	jse.executeScript("scroll(900,1200);");
	Thread.sleep(3000);
	Thread.sleep(1000);
	
	
	System.out.println("Phone-3");
	System.out.println(driver.findElement(By.xpath("/html/body/div[1]/div/div[3]/div[2]/div[1]/div[2]/div[7]/div/div/div/a/div[2]/div[1]/div[1]")).getText());
	System.out.println(driver.findElement(By.xpath("/html/body/div[1]/div/div[3]/div[2]/div[1]/div[2]/div[7]/div/div/div/a/div[2]/div[2]/div[1]/div/div")).getText());
	Thread.sleep(1000);
	jse.executeScript("scroll(1200,1500);");
	Thread.sleep(3000);
	
	System.out.print("Phone-4");
	System.out.println(driver.findElement(By.xpath("/html/body/div[1]/div/div[3]/div[2]/div[1]/div[2]/div[13]/div/div/div/a/div[2]/div[1]/div[1]")).getText());
	System.out.println(driver.findElement(By.xpath("/html/body/div[1]/div/div[3]/div[2]/div[1]/div[2]/div[13]/div/div/div/a/div[2]/div[2]/div[1]/div/div[1]")).getText());
	Thread.sleep(1000);
	jse.executeScript("scroll(1500,1800);");
	Thread.sleep(3000);
	
	System.out.print("Phone-5");
	System.out.println(driver.findElement(By.xpath("/html/body/div[1]/div/div[3]/div[2]/div[1]/div[2]/div[13]/div/div/div/a/div[2]/div[1]/div[1]")).getText());
	System.out.println(driver.findElement(By.xpath("/html/body/div[1]/div/div[3]/div[2]/div[1]/div[2]/div[13]/div/div/div/a/div[2]/div[2]/div[1]/div/div[1]")).getText());
	Thread.sleep(1000);
	jse.executeScript("scroll(1800,2100);");
	Thread.sleep(3000);
	
	Thread.sleep(200);
	driver.quit();	
		
	}

}

